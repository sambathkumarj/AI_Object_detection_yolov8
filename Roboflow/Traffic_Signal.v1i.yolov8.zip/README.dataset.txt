# Traffic_Signal > 2023-09-15 3:42pm
https://universe.roboflow.com/netcon/traffic_signal-zmm7q

Provided by a Roboflow user
License: CC BY 4.0

